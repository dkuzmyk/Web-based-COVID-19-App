//
// State Census Information
//

namespace program.Models
{

  public class StateCensus
	{
	
// data members with auto-generated getters and setters:
	  public string StateName { get; set; }
    public int Year {get;set;}
    public int Population {get; set;}
	
 // default constructor:
		public StateCensus()
		{ }

 // constructor:
		public StateCensus(string name, int yr, int popu)
		{
			StateName = name;   
      Year = yr;
			Population = popu;
		}
		
	}//end of class StateCensus

}//namespace